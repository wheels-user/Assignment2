package Main2014302580017;

import java.io.File;
import java.io.FileWriter;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Main2014302580017 {
	public static void main(String[] args){
		String name,profTitle,reshArea,phone,email;
		String newLine = System.lineSeparator(); 
		String tab = "	";
		try {
			URL url = new URL("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Ai%20Xin%20Ping");

			Scanner in = new Scanner(System.in);
			
			System.out.println("������Ҫ��ȡ��ʦ��ҳ����ַ������������Ĭ��Ϊ����ƽ��ʦ����ҳ��");
			String input = in.nextLine();
			
			
			while(!input.isEmpty()) {
				try{
				 URL urltest = new URL(input);
				 HttpURLConnection con = (HttpURLConnection) urltest.openConnection();  
			     if(con.getResponseCode() != 200) {
			    	 throw new ConnectException();
			     }
			     else {
			    	 url = urltest;
			    	 break;
			     }
				}catch(Exception e){
					 System.out.println("URL�������������루����������Ĭ��Ϊ����ƽ��ʦ����ҳ��");
				     input = in.nextLine();
				}
			}
			
			in.close();
			//
			Document doc = Jsoup.parse(url,3000);
			
			//����������ְ�ƣ��о�������ϵ�绰��EMAIL��div
			Element div = doc.getElementsByAttributeValue("class", 
					"details col-md-10 col-sm-9 col-xs-7").first();
			name = div.getElementsByTag("h3").text();
			
			
			Element p = div.getElementsByTag("p").first();
			
			//�������ʽ,ʹ��<br>�ָ�
			Pattern pt = Pattern.compile("[<br>]+");
			String[] details = pt.split(p.html());
			
			profTitle = details[0].trim();
			reshArea = details[1].trim();
			phone = details[2].trim();
			email = details[3].trim();
			
			
			
			//���
			//Elements font = doc.getElementsByTag("font");
			Elements contents = doc.getElementsByClass("szll_wz");
			
			
			//���
			FileWriter fw = new FileWriter(new File(name+".txt"));
			StringBuilder sb = new StringBuilder();
			sb.append("��ʦ������ ");
			sb.append(name+newLine);
			sb.append("ְ�ƣ� ");
			sb.append(profTitle+newLine);
			sb.append(reshArea+newLine);
			sb.append(phone+newLine);
			sb.append(email+newLine);
			
			//������
			sb.append("��飺"+newLine);
			for(Element e:contents) {
				Element title = e.getElementsByClass("szll_wz_bt").first();
				sb.append(title.text()+newLine);
				Elements ps = e.getElementsByTag("p");
				for(Element pp:ps){
					sb.append(tab+pp.text()+newLine);
				}
				
				
			}
			
			
			
			fw.write(sb.toString());
			fw.flush();
			fw.close();
			
			System.out.println(name+".txt ���ɳɹ�");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
